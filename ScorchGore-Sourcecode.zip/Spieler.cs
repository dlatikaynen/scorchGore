﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScorchGore
{
    internal class Spieler
    {
        public string Name;
        public Brush Farbe;
        public int X;
        public int Y;
    }
}
