﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScorchGore")]
[assembly: AssemblyDescription("The Brutal Scorch Gore Death Ray Shooter Game")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("llatikay")]
[assembly: AssemblyProduct("ScorchGore")]
[assembly: AssemblyCopyright("Copyright © 2021 Lukas Sascha Latikaynen")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("e24cea5f-26e2-41e7-83aa-cc5b6efe4c10")]
[assembly: AssemblyVersion("0.5.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
