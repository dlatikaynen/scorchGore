﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScorchGore
{
    public partial class Main : Form
    {
        private SpielPhase spielPhase;
        private Bitmap levelBild;
        private Spieler spielerEins;
        private Spieler spielerZwei;

        public Main()
        {
            this.InitializeComponent();
            this.spielPhase = SpielPhase.WeltErzeugen;
            this.WeltErzeugen.Show();
            this.spielerEins = new Spieler
            {
                Name = "Noob",
                Farbe = Brushes.YellowGreen,
                X = 30,
                Y = 15
            };

            this.spielerZwei = new Spieler
            {
                Name = "Soos",
                Farbe = Brushes.MistyRose,
                X = this.Width - 30,
                Y = 15
            };
        }

        private void Main_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.None && (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Return))
            {
                if (this.spielPhase == SpielPhase.WeltErzeugen)
                {
                    this.spielPhase = SpielPhase.WeltWirdErzeugt;
                    this.ErzeugeDieWelt();
                }
            }
        }

        private void ErzeugeDieWelt()
        {
            this.WeltErzeugen.Hide();
            this.ScorchGore.Hide();
            this.Copyright.Hide();
            this.levelBild = new Bitmap(this.Width, this.Height, PixelFormat.Format24bppRgb);
            this.BackgroundImage = this.levelBild;
            /* berg-steilheit und rauhheit und höhenprofil mit zufallszahlen bestimmen */
            var minimumHoehe = Convert.ToInt32(Convert.ToDecimal(this.Height) * Convert.ToDecimal(this.MindesthoeheProzent.Value) / 100M);
            var maximumHoehe = Convert.ToInt32(Convert.ToDecimal(this.Height) * Convert.ToDecimal(this.HoechstHoeheProzent.Value) / 100M);
            var steilHeit = Convert.ToInt32(5 + this.RauheitsfaktorProzent.Value);
            var rauhHeit = 10M - Convert.ToDecimal(this.RauheitsfaktorProzent.Value / 20M);
            var zufallsZahl = new Random();
            var maximumHoehenunterschied = maximumHoehe - minimumHoehe;
            var aktuelleHoehe = Convert.ToDecimal(minimumHoehe + zufallsZahl.Next(maximumHoehenunterschied));
            var aktuelleRichtung = (zufallsZahl.Next(100) % 2) == 0;
            var aktuelleSteilheit = Convert.ToDecimal(Math.Max(1, zufallsZahl.Next(steilHeit)) * 0.22);
            var unveraenderteSteigung = Convert.ToInt32(zufallsZahl.NextDouble() * (double)rauhHeit);
            using (var zeichenFlaeche = Graphics.FromImage(this.levelBild))
            {                
                zeichenFlaeche.FillRectangle(Brushes.DarkSlateGray, zeichenFlaeche.ClipBounds);
                for (var bergX = 0; bergX < this.Width; bergX += 2)
                {
                    /* berg höhenänderung berechnen */
                    var hoehenAenderung = 0M;
                    if (aktuelleRichtung)
                    {
                        hoehenAenderung += aktuelleSteilheit;
                    }
                    else
                    {
                        hoehenAenderung -= aktuelleSteilheit;
                    }

                    aktuelleHoehe += hoehenAenderung;
                    if (aktuelleHoehe < 0)
                    {
                        aktuelleRichtung = true;
                        aktuelleHoehe = aktuelleSteilheit / 2M;
                    }
                    else if (aktuelleHoehe > maximumHoehenunterschied)
                    {
                        aktuelleRichtung = false;
                        aktuelleHoehe = maximumHoehenunterschied - aktuelleSteilheit / 2M;
                    }

                    /* berg zeichnen */
                    var pixelHoehe = minimumHoehe + Convert.ToInt32(aktuelleHoehe);
                    zeichenFlaeche.FillRectangle(Brushes.SlateBlue, bergX, (float)this.Height - pixelHoehe, 2f, (float)this.Height);

                    /* zacken in den berg machen */
                    if (--unveraenderteSteigung <= 0)
                    {
                        this.Refresh();
                        aktuelleRichtung = (zufallsZahl.Next(100) % 2) == 0;
                        aktuelleSteilheit = Convert.ToDecimal(Math.Max(1, zufallsZahl.Next(steilHeit)) * 0.22);
                        unveraenderteSteigung = Convert.ToInt32(zufallsZahl.NextDouble() * (double)rauhHeit);
                    }
                }
            }

            this.Refresh();
            this.spielPhase = SpielPhase.SpielerFallenRundeBeginnt;
            this.SpielerFallen(this.spielerEins);
            this.SpielerFallen(this.spielerZwei);
        }

        private void SpielerFallen(Spieler fallenderSpieler)
        {
            try
            {
                using (var zeichenFlaeche = Graphics.FromImage(this.levelBild))
                {
                    var weiterFallen = true;
                    var himmelsFarbe = this.levelBild.GetPixel(1, 1);
                    while (weiterFallen)
                    {
                        this.SpielerZeichnen(zeichenFlaeche, fallenderSpieler);
                        this.Refresh();
                        for (var schauenX = fallenderSpieler.X - 15; schauenX <= fallenderSpieler.X + 15; schauenX += 3)
                        {
                            if (this.levelBild.GetPixel(schauenX, fallenderSpieler.Y + 1) != himmelsFarbe)
                            {
                                weiterFallen = false;
                                break;
                            }
                        }

                        if (weiterFallen)
                        {
                            fallenderSpieler.Y += 2;
                        }                        
                    }
                }
            }
            finally
            {
                this.Refresh();
            }
        }

        private void SpielerZeichnen(Graphics zeichenFlaeche, Spieler gezeichneterSpieler)
        {
            zeichenFlaeche.FillRectangle(Brushes.DarkSlateGray, gezeichneterSpieler.X - 15, 0, 30, gezeichneterSpieler.Y);
            zeichenFlaeche.FillPie(
                gezeichneterSpieler.Farbe,
                gezeichneterSpieler.X-15,
                gezeichneterSpieler.Y-15,
                30,
                30,
                0f,
                -180f
            );
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}